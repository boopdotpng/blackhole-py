"""SFPU hazard/NOP probes: pair timing slopes and undetected-stall value checks.

Timing: 16 units per loop iteration at 64/128/256 iterations, slope per unit (cycles).
TIMING_CLEAR_CFG0_BITS=0x40000 enables .ttinsn fusion (bit 18 of cfg0 disables it).
Values: MAD writes NEW into a register holding OLD; the consumer runs with gap 0 or 1 (SFPNOP);
the result shows whether the consumer read OLD (hazard undetected) or NEW.
"""
import hashlib, json, os
from pathlib import Path
from statistics import median
from struct import pack, unpack

import pytest
from asm import Asm
from ttko.isa import R
from ttko.isa import Tensix as TT
from tests.profiler import Profiler
from tests.operation_pocs.sfpu_math.emit import constant, drain
from tests.movement.packer.pack import emit_pack_dst_to_cb
from tests.movement.unpacker.unpack import (
  F32, Sem, SemWait, Stall, Wait, _set_thread_cfg, configure_fp32_dst,
  emit_unpack_to_dst, publish_dst, sem_get, sem_post, sem_wait, stall,
)

COUNTS = (64, 128, 256)
BODY = 16
NOP = TT.TTSFPNOP()
MAD_L0 = TT.TTSFPMAD(1, 10, 9, 0, 0)  # L0 = L1*1 + 0, does not read L0

UNITS = {
  'nop': [NOP],
  'mad_chain': [TT.TTSFPMAD(0, 10, 9, 0, 0)],
  'mad_nop_chain': [TT.TTSFPMAD(0, 10, 9, 0, 0), NOP],
  'mad_ind4': None,  # filled below
  'mad_indep_mov': [MAD_L0, TT.TTSFPMOV(0, 3, 4, 0)],
  'mad_dep_mov': [MAD_L0, TT.TTSFPMOV(0, 0, 4, 0)],
  'mad_nop_dep_mov': [MAD_L0, NOP, TT.TTSFPMOV(0, 0, 4, 0)],
  'mad_nop_indep_mov': [MAD_L0, NOP, TT.TTSFPMOV(0, 3, 4, 0)],
  'mad_iadd_vc': [MAD_L0, TT.TTSFPIADD(0, 0, 4, 4)],
  'mad_iadd_vd': [MAD_L0, TT.TTSFPIADD(0, 3, 0, 4)],
  'mad_setsgn_vd': [MAD_L0, TT.TTSFPSETSGN(0, 3, 0, 0)],
  'mad_and_vb': [MAD_L0, TT.TTSFPAND(0, 3, 4, 1)],
  'mad_minmax': [MAD_L0, TT.TTSFPSWAP(0, 3, 0, 1)],
  'mad_nop_minmax': [MAD_L0, NOP, TT.TTSFPSWAP(0, 3, 0, 1)],
  'mad_swap': [MAD_L0, TT.TTSFPSWAP(0, 3, 0, 0)],
  'mad_shuf': [MAD_L0, TT.TTSFPSHFT2(0, 0, 4, 3)],
  'mad_loadi_lo': [MAD_L0, TT.TTSFPLOADI(0, 10, 0x1234)],
  'swap_mov': [TT.TTSFPSWAP(0, 3, 2, 1), TT.TTSFPMOV(0, 5, 6, 0)],
  'swap_nop_mov': [TT.TTSFPSWAP(0, 3, 2, 1), NOP, TT.TTSFPMOV(0, 5, 6, 0)],
  'swap_nop2_mov': [TT.TTSFPSWAP(0, 3, 2, 1), NOP, NOP, TT.TTSFPMOV(0, 5, 6, 0)],
  'shuf_mov': [TT.TTSFPSHFT2(0, 1, 2, 3), TT.TTSFPMOV(0, 5, 6, 0)],
  'shuf_nop_mov': [TT.TTSFPSHFT2(0, 1, 2, 3), NOP, TT.TTSFPMOV(0, 5, 6, 0)],
  'shft2_lreg_mov': [TT.TTSFPSHFT2(0, 1, 2, 5), TT.TTSFPMOV(0, 5, 6, 0)],
  'loadi_pair': [TT.TTSFPLOADI(4, 8, 0x3f80), TT.TTSFPLOADI(4, 10, 0)],
  'sfpload': [TT.TTSFPLOAD(4, 3, 0, 0)],
  'sfpstore': [TT.TTSFPSTORE(4, 3, 0, 0)],
  'load_mad_store': [TT.TTSFPLOAD(0, 3, 0, 0), TT.TTSFPMAD(0, 10, 9, 0, 0), TT.TTSFPSTORE(0, 3, 0, 0)],
  'load_mad_nop_store': [TT.TTSFPLOAD(0, 3, 0, 0), TT.TTSFPMAD(0, 10, 9, 0, 0), NOP, TT.TTSFPSTORE(0, 3, 0, 0)],
  'arecip_mad': [TT.TTSFPARECIP(0, 1, 0, 0), TT.TTSFPMAD(0, 10, 9, 4, 0)],
  'tt_nop_mad_dep': [MAD_L0, TT.TTNOP(), TT.TTSFPMOV(0, 0, 4, 0)],
}


def save(record):
  print('SFPU_HAZARD ' + json.dumps(record, sort_keys=True))
  if name := os.environ.get('TIMING_OUTPUT'):
    with Path(name).open('a') as f: f.write(json.dumps(record, sort_keys=True) + '\n')


def unit(case, i):
  if case == 'mad_ind4': return [TT.TTSFPMAD(i % 4, 10, 9, i % 4, 0)]
  return UNITS[case]


def build(case, count):
  k = Asm('trisc1')
  clear_bits = int(os.environ.get('TIMING_CLEAR_CFG0_BITS', '0'), 0)
  saved = None
  if clear_bits:
    saved, mask = k.reg(2)
    k.li(mask, clear_bits)
    k.csrrc(saved, mask, 0x7c0)
  counter = k.reg()
  k.emit(TT.TTSFPENCC(0, 0, 0, 2))
  for reg in range(8): constant(k, reg, 1.)
  drain(k)
  k.fence()
  p = Profiler(k)
  k.li(counter, count)
  p.record('body')
  k.label('timed_loop')
  for i in range(BODY):
    for w in unit(case, i): k.emit(w)
  k.addi(counter, counter, -1)
  k.bne(counter, R.ZERO, 'timed_loop')
  drain(k)
  p.record('body')
  if saved is not None: k.csrrs(R.ZERO, saved, 0x7c0)
  return k.lower(), p


@pytest.mark.parametrize('case', list(UNITS))
def test_pair_timing(bh, request, case):
  rows = []
  for count in COUNTS:
    image, p = build(case, count)
    samples = []
    for s in range(8):
      bh.launch({'trisc1': image}, profiler=p)
      if s: samples.append(p.last['body'])
    rows.append(dict(iterations=count, units=BODY * count, raw_cycles=samples, median=median(samples),
                     min=min(samples), max=max(samples)))
  slopes = [(b['median'] - a['median']) / (b['units'] - a['units']) for a, b in zip(rows, rows[1:])]
  insns = len(unit(case, 0))
  save(dict(kind='timing', case=case, sfpu_insns_per_unit=insns, slopes_cycles_per_unit=slopes,
            loop_overhead_insns_per_unit=2 / BODY, points=rows, card=request.config.getoption('--bh-device'),
            core=list(bh.core), clear_cfg0_bits=os.environ.get('TIMING_CLEAR_CFG0_BITS', '0'),
            source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()))


# ---------------------------------------------------------------- value checks

INPUT, OUTPUT = 0x50000, 0x60000
SIZE = 8192
POISON = 0xA5A5A5A5
OLD, NEW, C3 = 0x3F800000, 0xC0A00000, 0x40400000  # 1.0, -5.0, 3.0


def li32(k, reg, bits):
  k.emit(TT.TTSFPLOADI(reg, 8, bits >> 16))
  k.emit(TT.TTSFPLOADI(reg, 10, bits & 65535))


# name: (consumer words, LReg to store, L3 value, expected NEW-read result, OLD-read result)
def f2b(x): return unpack('<I', pack('<f', x))[0]
VALUE_CASES = {
  'mov_detected': ([TT.TTSFPMOV(0, 0, 4, 0)], 4, C3, NEW, OLD),
  'iadd_vd': ([TT.TTSFPIADD(0, 3, 0, 4)], 0, 1, (NEW + 1) & 0xFFFFFFFF, OLD + 1),
  'iadd_vc_imm': ([TT.TTSFPIADD(1, 0, 4, 5)], 4, C3, NEW + 1, OLD + 1),
  'and_vb': ([TT.TTSFPAND(0, 3, 4, 1)], 4, 0xFFFFFFFF, NEW, OLD),
  'setsgn_vd': ([TT.TTSFPSETSGN(0, 3, 0, 0)], 0, C3, C3 | 0x80000000, C3),
  'minmax_min': ([TT.TTSFPSWAP(0, 3, 0, 1)], 0, C3, NEW, OLD),  # min(-5,3)=-5 ; stale compare sees 1<3: no swap
  'minmax_max': ([TT.TTSFPSWAP(0, 3, 0, 1)], 3, C3, C3, C3),
  'shuffle': ([TT.TTSFPSHFT2(0, 0, 4, 3)], 4, C3, NEW, OLD),
  'loadi_lower': ([TT.TTSFPLOADI(0, 10, 0x1234)], 0, C3, (NEW & 0xFFFF0000) | 0x1234, None),
}
# NEW=+5.0: correct compare (5 vs 3) swaps -> L0=3, L3=5; stale compare (1 vs 3) does not -> L0=5, L3=3.
POS5 = 0x40A00000
VALUE_CASES['minmax5_min'] = ([TT.TTSFPSWAP(0, 3, 0, 1)], 0, C3, C3, POS5)
VALUE_CASES['minmax5_max'] = ([TT.TTSFPSWAP(0, 3, 0, 1)], 3, C3, POS5, C3)
NEW_OVERRIDE = {'minmax5_min': POS5, 'minmax5_max': POS5}


def value_images(case, gap):
  loader, compute, packer = (Asm(r) for r in ('trisc0', 'trisc1', 'trisc2'))
  n = loader.reg(); loader.li(n, SIZE * 4)
  emit_unpack_to_dst(loader, INPUT, n, 0, 0)
  compute.emit(TT.TTZEROACC(3, 1, 0, 1, 0))
  stall(compute, Stall.SYNC, Wait.MATH)
  sem_post(compute, Sem.MATH_DONE)
  sem_wait(compute, Sem.UNPACK_TO_DEST, SemWait.ON_ZERO, Stall.SYNC)
  sem_get(compute, Sem.UNPACK_TO_DEST)
  configure_fp32_dst(compute, 0)
  for register in (12, 28, 47): _set_thread_cfg(compute, register, 0)
  compute.emit(TT.TTSETRWC(0, 0, 0, 0, 0, 0xF))
  words, out, l3, _, _ = VALUE_CASES[case]
  for pos in range(4):
    compute.emit(TT.TTSFPENCC(0, 0, 0, 2))
    li32(compute, 0, OLD); li32(compute, 1, NEW_OVERRIDE.get(case, NEW)); li32(compute, 3, l3); li32(compute, 4, 0)
    drain(compute)
    compute.emit(MAD_L0)
    for _ in range(gap): compute.emit(NOP)
    for w in words: compute.emit(w)
    drain(compute)
    compute.emit(TT.TTSFPSTORE(out, 3, 0, 8 + pos * 2))  # slot 1
  drain(compute); publish_dst(compute)
  n = packer.reg(); packer.li(n, SIZE)
  emit_pack_dst_to_cb(packer, 0, OUTPUT, n, output_format=F32)
  return {k.role: k.lower() for k in (loader, compute, packer)}


@pytest.mark.parametrize('gap', (0, 1))
@pytest.mark.parametrize('case', list(VALUE_CASES))
def test_hazard_values(bh, request, case, gap):
  imgs = value_images(case, gap)
  results = []
  for _ in range(4):
    bh.launch(imgs, l1={INPUT: pack('<I', POISON) * SIZE, OUTPUT: b'\x5a' * (SIZE * 4)})
    got = unpack(f'<{SIZE}I', bh.read_l1(bh.core, OUTPUT, SIZE * 4))
    slot = [w for w in got[128:256]]
    results.append(sorted(set(slot)))
  _, _, _, new, old = VALUE_CASES[case]
  seen = sorted({v for r in results for v in r})
  verdict = 'new' if seen == [new] else 'old' if seen == [old] else 'other'
  save(dict(kind='value', case=case, gap=gap, seen=[hex(v) for v in seen], expect_new=hex(new) if new is not None else None,
            expect_old=hex(old) if old is not None else None, verdict=verdict,
            card=request.config.getoption('--bh-device'), core=list(bh.core)))


@pytest.fixture(scope='module', autouse=True)
def prefetch_on(bh):
  k = Asm('brisc'); v = k.reg(); k.li(v, 0x11F); k.write(0xFFEF0000 + 208 * 4, v); k.fence()
  bh.launch({'brisc': k.lower()})
