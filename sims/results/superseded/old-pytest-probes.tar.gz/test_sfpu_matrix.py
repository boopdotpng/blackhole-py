"""SFPU producer x consumer matrix: timing slopes (gap 0 / 1 SFPNOP) and old/new value verdicts.

Every producer writes L0. Every consumer has L0 in exactly one operand role (or reads it implicitly).
Values need no per-op oracle: for each pair one launch runs four variants and stores L0..L7 (+ a lane-flag probe and
the consumer's Dst store target) into Dst, packed to L1:
  ref     producer; 3 SFPNOP; consumer      (correct result)
  noprod  SFPNOP in place of the producer   (what a stale read of L0 produces)
  gap0    producer; consumer
  gap1    producer; SFPNOP; consumer
verdict(gapN) = new if == ref, old if == noprod, else other. 'insensitive' when ref == noprod.
Timing: unit [producer, SFPNOP*gap, consumer] x16 per loop iteration, slope from 32 vs 96 iterations.

  python -m pytest sims/probes/test_sfpu_matrix.py --bh-hardware --bh-device 1
"""
import json, os
from pathlib import Path
from statistics import median
from struct import pack, unpack

import pytest
from asm import Asm
from ttko.isa import R, TensixWord, Tensix as TT
from tests.profiler import Profiler
from tests.operation_pocs.sfpu_math.emit import drain
from tests.movement.packer.pack import emit_pack_dst_to_cb
from tests.movement.unpacker.unpack import (
  F32, Sem, SemWait, Stall, Wait, _set_thread_cfg, configure_fp32_dst,
  emit_unpack_to_dst, publish_dst, sem_get, sem_post, sem_wait, stall,
)

OP = dict(ABS=0x7d, ADD=0x85, ADDI=0x75, AND=0x7e, ARECIP=0x99, CAST=0x90, COMPC=0x8b, CONFIG=0x91, DIVP2=0x76,
          ENCC=0x8a, EXEXP=0x77, EXMAN=0x78, GT=0x97, IADD=0x79, LE=0x96, LOAD=0x70, LOADI=0x71, LOADMACRO=0x93,
          LUT=0x73, LUTFP32=0x95, LZ=0x81, MAD=0x84, MOV=0x7c, MUL=0x86, MUL24=0x98, MULI=0x74, NOP=0x8f, NOT=0x80,
          OR=0x7f, POPC=0x88, PUSHC=0x87, SETCC=0x7b, SETEXP=0x82, SETMAN=0x83, SETSGN=0x89, SHFT=0x7a, SHFT2=0x94,
          STORE=0x72, SWAP=0x92, TRANSP=0x8c, XOR=0x8d, STOCHRND=0x8e)


def W(op, vd=0, vc=0, vb=0, va=0, mod=0, imm12=None, imm16=None, mod0=None, low=0, mirror=0, rnd=0, imm5=0):
  o = OP[op] << 24
  if op in ('LOAD', 'LOADI', 'STORE', 'LUT', 'LOADMACRO'):
    w = o | vd << 20 | (mod0 or 0) << 16 | low
  elif op in ('ADDI', 'MULI', 'CONFIG'):
    w = o | (imm16 or 0) << 8 | vd << 4 | mod
  elif op == 'LUTFP32':
    w = o | mirror << 16 | vd << 4 | mod
  elif op == 'STOCHRND':
    w = o | rnd << 21 | imm5 << 16 | vb << 12 | vc << 8 | vd << 4 | mod
  elif op in ('MAD', 'MUL', 'ADD', 'MUL24'):
    w = o | va << 16 | vb << 12 | vc << 8 | vd << 4 | mod
  else:
    w = o | (vb if imm12 is None else imm12) << 12 | vc << 8 | vd << 4 | mod
  return TensixWord(w)


NOP = W('NOP')
INIT = {0: 0x3F800003, 1: 0x40200001, 2: 0xBF400000, 3: 0x3FC00000, 4: 0x12345678, 5: 0x00000003, 6: 0x3F000000,
        7: 0x00000004}

# Producers: write L0, sources from L1..L3 / constants. (name, word)
PRODUCERS = [
  ('MAD', W('MAD', 0, va=1, vb=2, vc=3)), ('MUL', W('MUL', 0, va=1, vb=2, vc=9)), ('ADD', W('ADD', 0, va=10, vb=1, vc=2)),
  ('ADDI', W('ADDI', 0, imm16=0x4000)), ('MULI', W('MULI', 0, imm16=0xC000)), ('MUL24', W('MUL24', 0, va=1, vb=2, vc=9)),
  ('MUL24.upper', W('MUL24', 0, va=1, vb=2, vc=9, mod=1)),
  ('LUT', W('LUT', 0, mod0=0)), ('LUTFP32.m0', W('LUTFP32', 0, mod=0)), ('LUTFP32.m2', W('LUTFP32', 0, mod=2)),
  ('MOV', W('MOV', 0, vc=1)), ('ABS.f', W('ABS', 0, vc=2, mod=1)), ('IADD.imm', W('IADD', 0, vc=1, imm12=5, mod=5)),
  ('IADD.reg', W('IADD', 0, vc=1, mod=4)), ('SHFT.imm', W('SHFT', 0, imm12=3, mod=1)), ('AND.vb', W('AND', 0, vc=2, vb=1, mod=1)),
  ('OR.vb', W('OR', 0, vc=2, vb=1, mod=1)), ('XOR', W('XOR', 0, vc=1)), ('NOT', W('NOT', 0, vc=1)), ('LZ', W('LZ', 0, vc=1)),
  ('EXEXP', W('EXEXP', 0, vc=1)), ('EXMAN', W('EXMAN', 0, vc=1)), ('SETEXP.imm', W('SETEXP', 0, vc=1, imm12=0x80, mod=1)),
  ('SETMAN.imm', W('SETMAN', 0, vc=1, imm12=0x123, mod=1)), ('SETSGN.imm', W('SETSGN', 0, vc=1, imm12=1, mod=1)),
  ('DIVP2', W('DIVP2', 0, vc=1, imm12=2, mod=1)), ('ARECIP', W('ARECIP', 0, vc=1)), ('ARECIP.exp', W('ARECIP', 0, vc=2, mod=2)),
  ('CAST', W('CAST', 0, vc=5, mod=0)), ('STOCHRND.f16b', W('STOCHRND', 0, vc=1, mod=1)),
  ('STOCHRND.u8', W('STOCHRND', 0, vc=5, mod=4 | 8, imm5=1)),
  ('LOADI', W('LOADI', 0, mod0=0, low=0x4321)), ('LOAD', W('LOAD', 0, mod0=3, low=0)),
  ('GT.setvd', W('GT', 0, vc=2, mod=8)), ('LE.setvd', W('LE', 0, vc=2, mod=8)),
  ('SWAP.m0', W('SWAP', 0, vc=1, mod=0)), ('SWAP.m1', W('SWAP', 0, vc=1, mod=1)),
  ('SHFT2.m0', W('SHFT2', 0, vc=5, mod=0)), ('SHFT2.m2', W('SHFT2', 0, vc=1, mod=2)), ('SHFT2.m3', W('SHFT2', 0, vc=1, mod=3)),
  ('SHFT2.m4', W('SHFT2', 0, vc=1, mod=4)), ('SHFT2.m5', W('SHFT2', 0, vb=1, vc=5, mod=5)),
  ('SHFT2.m6', W('SHFT2', 0, vb=1, imm12=(3 << 4) | 1, mod=6)), ('TRANSP', W('TRANSP')),
]

# Consumers: L0 in one role; output to L4 unless the role is vd. (name, word)
CONSUMERS = [
  ('MOV.vc', W('MOV', 4, vc=0)), ('ABS.vc', W('ABS', 4, vc=0, mod=1)),
  ('MAD.va', W('MAD', 4, va=0, vb=5, vc=6)), ('MAD.vb', W('MAD', 4, va=6, vb=0, vc=5)), ('MAD.vc', W('MAD', 4, va=6, vb=5, vc=0)),
  ('MUL.va', W('MUL', 4, va=0, vb=6, vc=9)), ('ADD.vc', W('ADD', 4, va=10, vb=6, vc=0)),
  ('ADDI.vd', W('ADDI', 0, imm16=0x3F80)), ('MULI.vd', W('MULI', 0, imm16=0x4000)),
  ('MUL24.va', W('MUL24', 4, va=0, vb=6, vc=9)), ('MUL24.vb', W('MUL24', 4, va=6, vb=0, vc=9)),
  ('LUT.impl', W('LUT', 4, mod0=0)), ('LUTFP32.impl', W('LUTFP32', 4, mod=0)),
  ('LUTFP32.mirror8', W('LUTFP32', 4, mod=0, mirror=8)),
  ('IADD.vc.imm', W('IADD', 4, vc=0, imm12=1, mod=5)), ('IADD.vc.reg', W('IADD', 4, vc=0, mod=4)),
  ('IADD.vd.reg', W('IADD', 0, vc=5, mod=4)), ('IADD.vd.sub', W('IADD', 0, vc=5, mod=6)),
  ('SHFT.vd.imm', W('SHFT', 0, imm12=2, mod=1)), ('SHFT.vd.reg', W('SHFT', 0, vc=5, mod=0)), ('SHFT.vc.reg', W('SHFT', 4, vc=0, mod=0)),
  ('SHFT.vc.immvc', W('SHFT', 4, vc=0, imm12=2, mod=5)),
  ('AND.vc', W('AND', 4, vc=0, vb=6, mod=1)), ('AND.vd', W('AND', 0, vc=6, mod=0)), ('AND.vb', W('AND', 4, vc=6, vb=0, mod=1)),
  ('OR.vb', W('OR', 4, vc=6, vb=0, mod=1)), ('OR.vd', W('OR', 0, vc=6, mod=0)),
  ('XOR.vc', W('XOR', 4, vc=0)), ('XOR.vd', W('XOR', 0, vc=6)), ('NOT.vc', W('NOT', 4, vc=0)), ('LZ.vc', W('LZ', 4, vc=0)),
  ('EXEXP.vc', W('EXEXP', 4, vc=0)), ('EXMAN.vc', W('EXMAN', 4, vc=0)),
  ('SETEXP.vc.imm', W('SETEXP', 4, vc=0, imm12=0x81, mod=1)), ('SETEXP.vd', W('SETEXP', 0, vc=6, mod=0)),
  ('SETEXP.vc.reg', W('SETEXP', 4, vc=0, mod=0)),
  ('SETMAN.vc.imm', W('SETMAN', 4, vc=0, imm12=0x7, mod=1)), ('SETMAN.vd', W('SETMAN', 0, vc=6, mod=0)),
  ('SETSGN.vc.imm', W('SETSGN', 4, vc=0, imm12=1, mod=1)), ('SETSGN.vd', W('SETSGN', 0, vc=6, mod=0)),
  ('DIVP2.vc', W('DIVP2', 4, vc=0, imm12=1, mod=1)), ('ARECIP.vc', W('ARECIP', 4, vc=0)),
  ('ARECIP.cond.vb', W('ARECIP', 4, vc=6, vb=0, mod=1)), ('ARECIP.cond.vc', W('ARECIP', 4, vc=0, vb=2, mod=1)),
  ('CAST.vc', W('CAST', 4, vc=0)), ('STOCHRND.vc', W('STOCHRND', 4, vc=0, mod=1)),
  ('STOCHRND.vb', W('STOCHRND', 4, vc=5, vb=0, mod=4)),
  ('SETCC.vc', W('SETCC', 0, vc=0, mod=0)), ('GT.vc', W('GT', 4, vc=0, mod=1)), ('GT.vd', W('GT', 0, vc=6, mod=1)),
  ('LE.vd', W('LE', 0, vc=6, mod=1)),
  ('SWAP.m0.vd', W('SWAP', 0, vc=6, mod=0)), ('SWAP.m0.vc', W('SWAP', 6, vc=0, mod=0)),
  ('SWAP.m1.vd', W('SWAP', 0, vc=6, mod=1)), ('SWAP.m1.vc', W('SWAP', 6, vc=0, mod=1)),
  ('SHFT2.m0.impl', W('SHFT2', 4, vc=6, mod=0)), ('SHFT2.m1.impl', W('SHFT2', 4, vc=6, mod=1)),
  ('SHFT2.m2.vc', W('SHFT2', 4, vc=0, mod=2)), ('SHFT2.m3.vc', W('SHFT2', 4, vc=0, mod=3)), ('SHFT2.m4.vc', W('SHFT2', 4, vc=0, mod=4)),
  ('SHFT2.m5.vb', W('SHFT2', 4, vb=0, vc=5, mod=5)), ('SHFT2.m5.vc', W('SHFT2', 4, vb=6, vc=0, mod=5)),
  ('SHFT2.m6.vb', W('SHFT2', 4, vb=0, imm12=(2 << 4), mod=6)),
  ('TRANSP.impl', W('TRANSP')), ('STORE', W('STORE', 0, mod0=3, low=0)),
  ('CONFIG.L12', W('CONFIG', 12, mod=0)),
  ('LOADI.lower', W('LOADI', 0, mod0=10, low=0x1234)), ('LOADI.upper', W('LOADI', 0, mod0=8, low=0x4110)),
  ('LOAD.lo16', W('LOAD', 0, mod0=14, low=0)), ('LOAD.hi16', W('LOAD', 0, mod0=15, low=0)),
  ('LOADI.full', W('LOADI', 0, mod0=0, low=0x4110)), ('MOV.waw', W('MOV', 0, vc=6)),
]


def save(record):
  if name := os.environ.get('TIMING_OUTPUT'):
    with Path(name).open('a') as f: f.write(json.dumps(record, sort_keys=True) + '\n')


@pytest.fixture(scope='module', autouse=True)
def prefetch_on(bh):
  k = Asm('brisc'); v = k.reg(); k.li(v, 0x11F); k.write(0xFFEF0000 + 208 * 4, v); k.fence()
  bh.launch({'brisc': k.lower()})


def li32(k, reg, bits):
  k.emit(TT.TTSFPLOADI(reg, 8, bits >> 16))
  k.emit(TT.TTSFPLOADI(reg, 10, bits & 65535))


def init_regs(k):
  for r, v in INIT.items(): li32(k, r, v)


# ---------------------------------------------------------------- timing

COUNTS = (32, 96)
BODY = 16


def slope(bh, unit):
  meds = []
  for count in COUNTS:
    k = Asm('trisc1'); counter = k.reg()
    k.emit(TT.TTSFPENCC(0, 0, 0, 2)); init_regs(k); drain(k); k.fence()
    p = Profiler(k)
    k.li(counter, count)
    p.record('body')
    k.label('loop')
    for _ in range(BODY):
      for w in unit: k.emit(w)
    k.addi(counter, counter, -1)
    k.bne(counter, R.ZERO, 'loop')
    drain(k)
    p.record('body')
    image = k.lower()
    s = []
    for i in range(4):
      bh.launch({'trisc1': image}, profiler=p)
      if i: s.append(p.last['body'])
    meds.append((median(s), max(s) - min(s)))
  return (meds[1][0] - meds[0][0]) / ((COUNTS[1] - COUNTS[0]) * BODY), max(m[1] for m in meds)


# ---------------------------------------------------------------- values

INPUT, OUTPUT, SIZE = 0x50000, 0x60000, 8192
POISON = 0xA5A5A5A5
VARIANTS = ('ref', 'noprod', 'gap0', 'gap1')
SLOTS = 11  # L0..L7, flags probe, store target, L12


def value_images(prod, cons):
  loader, compute, packer = (Asm(r) for r in ('trisc0', 'trisc1', 'trisc2'))
  n = loader.reg(); loader.li(n, SIZE * 4)
  emit_unpack_to_dst(loader, INPUT, n, 0, 0)
  compute.emit(TT.TTZEROACC(3, 1, 0, 1, 0))
  stall(compute, Stall.SYNC, Wait.MATH)
  sem_post(compute, Sem.MATH_DONE)
  sem_wait(compute, Sem.UNPACK_TO_DEST, SemWait.ON_ZERO, Stall.SYNC)
  sem_get(compute, Sem.UNPACK_TO_DEST)
  configure_fp32_dst(compute, 0)
  for register in (12, 28, 47): _set_thread_cfg(compute, register, 0)
  compute.emit(TT.TTSETRWC(0, 0, 0, 0, 0, 0xF))
  for v, variant in enumerate(VARIANTS):
    base = 1 + v * SLOTS
    store_target = base + 9
    c = cons
    if (c >> 24) == OP['STORE']: c = TensixWord(c | store_target * 8)
    compute.emit(TT.TTSFPENCC(0, 0, 0, 2))
    init_regs(compute)
    li32(compute, 0, 0x0BADF00D); compute.emit(NOP); compute.emit(W('CONFIG', 12, mod=0)); compute.emit(NOP)
    init_regs(compute)
    compute.emit(TT.TTSFPENCC(3, 0, 0, 10))
    drain(compute)
    compute.emit(NOP if variant == 'noprod' else prod)
    for _ in range({'ref': 3, 'noprod': 3, 'gap0': 0, 'gap1': 1}[variant]): compute.emit(NOP)
    compute.emit(c)
    for _ in range(4): compute.emit(NOP)
    drain(compute)
    for r in range(8):
      for pos in range(4): compute.emit(TT.TTSFPSTORE(r, 3, 0, (base + r) * 8 + pos * 2))
    compute.emit(TT.TTSFPLOADI(4, 8, 0x7777))  # predicated: shows lane flags left by the consumer
    for pos in range(4): compute.emit(TT.TTSFPSTORE(4, 3, 0, (base + 8) * 8 + pos * 2))
    compute.emit(TT.TTSFPENCC(0, 0, 0, 2))
    compute.emit(W('MOV', 4, vc=12)); compute.emit(NOP)
    for pos in range(4): compute.emit(TT.TTSFPSTORE(4, 3, 0, (base + 10) * 8 + pos * 2))
    drain(compute)
  publish_dst(compute)
  n = packer.reg(); packer.li(n, SIZE)
  emit_pack_dst_to_cb(packer, 0, OUTPUT, n, output_format=F32)
  return {k.role: k.lower() for k in (loader, compute, packer)}


def values(bh, prod, cons):
  imgs = value_images(prod, cons)
  runs = []
  for _ in range(2):
    bh.launch(imgs, l1={INPUT: pack('<I', POISON) * SIZE, OUTPUT: b'\x5a' * (SIZE * 4)})
    got = unpack(f'<{SIZE}I', bh.read_l1(bh.core, OUTPUT, SIZE * 4))
    runs.append({var: got[(1 + v * SLOTS) * 128:(1 + (v + 1) * SLOTS) * 128] for v, var in enumerate(VARIANTS)})
  stable = runs[0] == runs[1]
  r = runs[0]
  out = {}
  if r['ref'] == r['noprod']:
    out = {'gap0': 'insensitive', 'gap1': 'insensitive'}
  else:
    for g in ('gap0', 'gap1'):
      out[g] = 'new' if r[g] == r['ref'] else 'old' if r[g] == r['noprod'] else 'other'
  diff = [i // 128 for i in range(len(r['ref'])) if r['ref'][i] != r['noprod'][i]]
  return out, stable, sorted(set(diff)), {g: [i // 128 for i in range(len(r['ref'])) if r[g][i] != r['ref'][i]][:1]
                                          for g in ('gap0', 'gap1')}


@pytest.mark.parametrize('pname', [p for p, _ in PRODUCERS])
def test_matrix(bh, request, pname):
  prod = dict(PRODUCERS)[pname]
  s, spread = slope(bh, [prod])
  save(dict(kind='single', name=pname, word=hex(prod), slope=s, spread=spread))
  for cname, cons in CONSUMERS:
    rec = dict(kind='pair', producer=pname, consumer=cname, pword=hex(prod), cword=hex(cons))
    for gap in (0, 1):
      s, spread = slope(bh, [prod] + [NOP] * gap + [cons])
      rec[f'slope_gap{gap}'] = s; rec[f'spread_gap{gap}'] = spread
    v, stable, slots, first_bad = values(bh, prod, cons)
    rec.update(value_gap0=v['gap0'], value_gap1=v['gap1'], stable=stable, sensitive_slots=slots, first_bad=first_bad)
    save(rec)


@pytest.mark.parametrize('cname', [c for c, _ in CONSUMERS])
def test_consumer_single(bh, request, cname):
  cons = dict(CONSUMERS)[cname]
  s, spread = slope(bh, [cons])
  save(dict(kind='single', name='C:' + cname, word=hex(cons), slope=s, spread=spread))
