"""Hardware probes for sims/. They borrow blackhole-py-old's raw-assembly harness (Asm, Profiler, Device boot, `bh`).

  python3 sims/probes/sweep.py --device 1 --output sims/results/<date>-<name>-card1.jsonl sims/probes/test_X.py
  (or directly: python3 -m pytest sims/probes/test_X.py --bh-hardware --bh-device 1 --bh-timeout 0.5)
  TIMING_OUTPUT=<path>.jsonl  appends one JSON record per case; failures go to <path>.jsonl.failed.

Failure policy (never resets the card):
  soft  KernelTimeout: a bounded kernel gave up and returned to firmware. Recorded, the session continues.
  hard  anything else (host-side launch timeout, boot error, ...): the tile may still be running or the NoC wedged,
        so the session stops right away. Reset by hand (python3 smi.py -r N) and rerun the sweep to resume.

Per-case host timeout: --bh-timeout (sweep.py passes 0.5 s; kernels take ~1 ms) or @pytest.mark.bh_timeout(seconds).

BLACKHOLE_PY_OLD overrides the harness checkout (default: ../blackhole-py-old next to this repo).
Probes boot the old firmware; each module re-applies the settings the current firmware uses that the old one
does not (instruction prefetch 0x11F). Fusion on / L0 data cache off already match.
"""
import json, os, sys, time
from pathlib import Path

import pytest

OLD = Path(os.environ.get('BLACKHOLE_PY_OLD', Path(__file__).resolve().parents[3] / 'blackhole-py-old'))
if not (OLD / 'asm.py').exists(): raise RuntimeError(f'blackhole-py-old harness not found at {OLD}')
sys.path.insert(0, str(OLD))

from tests.conftest import pytest_addoption, card, bh  # noqa: E402,F401


def pytest_configure(config):
  config.addinivalue_line('markers', 'bh_timeout(seconds): host-side timeout for each launch in this case')


@pytest.fixture(autouse=True)
def _case_timeout(request):
  if 'bh' not in request.fixturenames:
    yield
    return
  harness = request.getfixturevalue('bh')
  mark = request.node.get_closest_marker('bh_timeout')
  harness.timeout = float(mark.args[0]) if mark else request.config.getoption('--bh-timeout')
  yield


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
  report = (yield).get_result()
  if not report.failed: return
  soft = call.excinfo is not None and call.excinfo.typename == 'KernelTimeout'
  error = '' if call.excinfo is None else f'{call.excinfo.typename}: {call.excinfo.value}'
  if name := os.environ.get('TIMING_OUTPUT'):
    rec = dict(test=item.nodeid, kind='soft' if soft else 'hard', when=call.when, error=error[:500], time=time.time())
    with Path(name + '.failed').open('a') as f: f.write(json.dumps(rec) + '\n')
  if not soft:
    item.session.shouldstop = f'hard failure in {item.nodeid} ({error[:200]}); not resetting - reset by hand'
