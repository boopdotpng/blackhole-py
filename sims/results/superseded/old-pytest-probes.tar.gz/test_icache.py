"""Instruction-cache cost: straight-line body of N instructions in a loop, cold first pass and steady slope.

Per role, body kind (RISC addi / fused .ttinsn SFPNOP / ttinsn TTNOP), N, and prefetcher setting.
RISC_PREFETCH_CTRL (Tensix cfg reg 208) is written by the kernel itself: 0 = off, 0x11F = current blackhole-py fw.
"""
import json, os
from pathlib import Path
from statistics import median

import pytest
from asm import Asm
from ttko.isa import R, Tensix as TT
from tests.profiler import Profiler
from tests.operation_pocs.sfpu_math.emit import drain

PREFETCH = 0xFFEF0000 + 208 * 4
PASSES = (4, 8, 16)
SIZES = (32, 64, 96, 120, 128, 160, 256, 480, 512, 1024)


def save(record):
  print('ICACHE ' + json.dumps(record, sort_keys=True))
  if name := os.environ.get('TIMING_OUTPUT'):
    with Path(name).open('a') as f: f.write(json.dumps(record, sort_keys=True) + '\n')


def build(role, kind, n, passes, prefetch):
  k = Asm(role)
  counter, x = k.reg(2)
  p = Profiler(k)
  k.li(counter, passes)
  k.li(x, 0)
  p.record('loop')
  k.label('loop')
  for _ in range(n):
    if kind == 'addi': k.addi(x, x, 1)
    elif kind == 'sfpnop': k.emit(TT.TTSFPNOP())
    else: k.emit(TT.TTNOP())
  k.addi(counter, counter, -1)
  k.bne(counter, R.ZERO, 'loop')
  if kind != 'addi': drain(k)
  else: k.fence()
  p.record('loop')
  return k.lower(), p


CASES = [(r, 'addi') for r in ('brisc', 'ncrisc', 'trisc0', 'trisc1', 'trisc2')] + [('trisc1', 'sfpnop'), ('trisc0', 'ttnop')]


@pytest.fixture(scope='module', autouse=True)
def prefetch_on(bh):
  k = Asm('brisc'); v = k.reg(); k.li(v, 0x11F); k.write(PREFETCH, v); k.fence()
  bh.launch({'brisc': k.lower()})


@pytest.mark.parametrize('role,kind', CASES)
def test_icache(bh, request, role, kind, prefetch=0x11F):
  for n in SIZES:
    pts = []
    for passes in PASSES:
      image, p = build(role, kind, n, passes, prefetch)
      s = []
      for i in range(6):
        bh.launch({role: image}, profiler=p)
        if i: s.append(p.last['loop'])
      pts.append(dict(passes=passes, median=median(s), raw=s))
    steady = [(b['median'] - a['median']) / (b['passes'] - a['passes']) for a, b in zip(pts, pts[1:])]
    first = pts[0]['median'] - steady[0] * (pts[0]['passes'] - 1)
    save(dict(role=role, kind=kind, n=n, prefetch=hex(prefetch), steady_per_pass=steady,
              steady_per_insn=steady[-1] / (n + 2), first_pass=first, cold_extra=first - steady[-1],
              points=pts, card=request.config.getoption('--bh-device')))
