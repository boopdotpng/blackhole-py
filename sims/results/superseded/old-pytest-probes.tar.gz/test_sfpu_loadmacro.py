"""SFPLOADMACRO: throughput with 0-4 scheduled sub-units, execution cycle of each delay, and collisions with regular
instructions. Card 1 results: sims/results/<date>-sfpu-loadmacro-card1.jsonl.

  python -m pytest sims/probes/test_sfpu_loadmacro.py --bh-hardware --bh-device 1
"""
import json, os
from pathlib import Path
from statistics import median
from struct import pack, unpack

import pytest
from asm import Asm
from ttko.isa import R, TensixWord, Tensix as TT
from tests.profiler import Profiler
from tests.operation_pocs.sfpu_math.emit import drain
from tests.movement.packer.pack import emit_pack_dst_to_cb
from tests.movement.unpacker.unpack import (
  F32, Sem, SemWait, Stall, Wait, _set_thread_cfg, configure_fp32_dst,
  emit_unpack_to_dst, publish_dst, sem_get, sem_post, sem_wait, stall,
)
from test_sfpu_matrix import W, NOP, INIT, li32, init_regs, save, prefetch_on  # noqa: F401

SIMPLE, MAD, ROUND, STORE = range(4)


def lm(slot=0, vd=0, mod0=3, addrmod=0, addr=0):
  return TensixWord(0x93 << 24 | slot << 22 | (vd & 3) << 20 | mod0 << 16 | addrmod << 13 | addr)


def byte(sel, delay=0, x_in_vb=0, l16=0):
  return sel | delay << 3 | l16 << 6 | x_in_vb << 7


def configure(k, slot, templates, units, misc=3):
  """templates: up to 4 words (VD field replaced by 12+i, backdoor write). units: {unit: byte}."""
  for i, t in enumerate(templates):
    k.emit(TensixWord(t & ~0xF0 | (12 + i) << 4))
  seq = sum(b << 8 * u for u, b in units.items())
  k.emit(TT.TTSFPLOADI(0, 8, seq >> 16))
  k.emit(TT.TTSFPLOADI(0, 10, seq & 0xFFFF))
  k.emit(NOP)
  k.emit(W('CONFIG', 4 + slot, mod=0))
  k.emit(W('CONFIG', 8, imm16=misc, mod=1))
  k.emit(NOP)


NEG = W('MOV', 0, vc=0, mod=1)              # simple: x = -x
HALF = W('MUL', 0, va=6, vb=0, vc=9)        # mad (x in VB): x = 0.5 * x
RND = W('STOCHRND', 0, vc=0, mod=1)         # round: fp32 -> fp16b-rounded fp32
TEMPLATES = [NEG, HALF, RND]

CONFIGS = {
  'none': {},
  'simple': {SIMPLE: byte(4)},
  'mad': {MAD: byte(5, x_in_vb=1)},
  'round': {ROUND: byte(6)},
  'store': {STORE: byte(3, delay=2)},
  'simple+store': {SIMPLE: byte(4), STORE: byte(3, delay=1)},
  'simple+mad': {SIMPLE: byte(4), MAD: byte(5, delay=1, x_in_vb=1)},
  'all4': {SIMPLE: byte(4), MAD: byte(5, delay=1, x_in_vb=1), ROUND: byte(6, delay=3, l16=1), STORE: byte(3, delay=4)},
}

COUNTS, BODY = (32, 96), 16


def slope(bh, config, unit):
  meds = []
  for count in COUNTS:
    k = Asm('trisc1'); counter = k.reg()
    k.emit(TT.TTSFPENCC(0, 0, 0, 2)); init_regs(k)
    configure(k, 0, TEMPLATES, CONFIGS[config])
    drain(k); k.fence()
    p = Profiler(k)
    k.li(counter, count)
    p.record('body')
    k.label('loop')
    for i in range(BODY):
      for w in unit(i): k.emit(w)
    k.addi(counter, counter, -1)
    k.bne(counter, R.ZERO, 'loop')
    for _ in range(8): k.emit(NOP)
    drain(k)
    p.record('body')
    image = k.lower()
    s = []
    for i in range(4):
      bh.launch({'trisc1': image}, profiler=p)
      if i: s.append(p.last['body'])
    meds.append(median(s))
  return (meds[1] - meds[0]) / ((COUNTS[1] - COUNTS[0]) * BODY)


UNITS = {
  'lm': lambda i: [lm(vd=i % 4)],
  'lm_nop': lambda i: [lm(vd=i % 4), NOP],
  'lm_mov': lambda i: [lm(vd=i % 4), W('MOV', 5, vc=6)],      # regular simple op right after
  'lm_mul': lambda i: [lm(vd=i % 4), W('MUL', 5, va=6, vb=6, vc=9)],  # regular MAD-unit op right after
  'lm_load': lambda i: [lm(vd=i % 4), W('LOAD', 5, mod0=3, low=0)],
}


@pytest.mark.parametrize('config', list(CONFIGS))
def test_throughput(bh, config):
  for name, unit in UNITS.items():
    save(dict(kind='loadmacro_timing', config=config, unit=name, slope=slope(bh, config, unit)))


# ---------------------------------------------------------------- values

INPUT, OUTPUT, SIZE = 0x50000, 0x60000, 8192
DST0 = 0x40000000  # 2.0 in Dst row 0 (all of slot 0)


def run(bh, config, body, misc=3):
  loader, compute, packer = (Asm(r) for r in ('trisc0', 'trisc1', 'trisc2'))
  n = loader.reg(); loader.li(n, SIZE * 4)
  emit_unpack_to_dst(loader, INPUT, n, 0, 0)
  compute.emit(TT.TTZEROACC(3, 1, 0, 1, 0))
  stall(compute, Stall.SYNC, Wait.MATH)
  sem_post(compute, Sem.MATH_DONE)
  sem_wait(compute, Sem.UNPACK_TO_DEST, SemWait.ON_ZERO, Stall.SYNC)
  sem_get(compute, Sem.UNPACK_TO_DEST)
  configure_fp32_dst(compute, 0)
  for register in (12, 28, 47): _set_thread_cfg(compute, register, 0)
  compute.emit(TT.TTSETRWC(0, 0, 0, 0, 0, 0xF))
  compute.emit(TT.TTSFPENCC(0, 0, 0, 2))
  configure(compute, 0, TEMPLATES, CONFIGS[config], misc)
  init_regs(compute)
  drain(compute)
  for w in body: compute.emit(w)
  for _ in range(8): compute.emit(NOP)
  drain(compute)
  for r in range(8):
    for pos in range(4): compute.emit(TT.TTSFPSTORE(r, 3, 0, (1 + r) * 8 + pos * 2))
  drain(compute); publish_dst(compute)
  n = packer.reg(); packer.li(n, SIZE)
  emit_pack_dst_to_cb(packer, 0, OUTPUT, n, output_format=F32)
  imgs = {k.role: k.lower() for k in (loader, compute, packer)}
  bh.launch(imgs, l1={INPUT: pack('<I', DST0) * SIZE, OUTPUT: b'\x5a' * (SIZE * 4)})
  got = unpack(f'<{SIZE}I', bh.read_l1(bh.core, OUTPUT, SIZE * 4))
  regs = {f'L{r}': hex(got[(1 + r) * 128]) for r in range(8)}
  regs['dst0'] = sorted({hex(v) for v in got[0:128]})
  return regs


def test_execution_cycle(bh):
  """Simple sub-unit NEG scheduled with delay d; a regular MOV L4 <- L0 issued k cycles after the LOADMACRO
  (k-1 SFPNOPs between) shows whether the scheduled write has happened: L4 = 2.0 (load only) or -2.0."""
  for d in range(4):
    CONFIGS[f'simple_d{d}'] = {SIMPLE: byte(4, delay=d)}
    for k in range(1, 7):
      body = [lm(vd=0)] + [NOP] * (k - 1) + [W('MOV', 4, vc=0)]
      save(dict(kind='loadmacro_exec', unit='simple', delay=d, k=k, **run(bh, f'simple_d{d}', body)))
  for d in range(3):
    CONFIGS[f'mad_d{d}'] = {MAD: byte(5, delay=d, x_in_vb=1)}
    for k in range(1, 7):
      body = [lm(vd=0)] + [NOP] * (k - 1) + [W('MOV', 4, vc=0)]
      save(dict(kind='loadmacro_exec', unit='mad', delay=d, k=k, **run(bh, f'mad_d{d}', body)))


def test_collisions(bh):
  """Regular instruction issued in the cycle a scheduled instruction executes on the same / a different sub-unit."""
  cases = {
    'simple_vs_regular_simple': ('simple', [lm(vd=0), W('MOV', 4, vc=6)]),          # MOV L4 <- 0.5 collides
    'simple_vs_regular_mad': ('simple', [lm(vd=0), W('MUL', 4, va=6, vb=6, vc=9)]),  # different sub-unit
    'mad_vs_regular_mad': ('mad', [lm(vd=0), W('MUL', 4, va=6, vb=6, vc=9)]),
    'mad_vs_regular_simple': ('mad', [lm(vd=0), W('MOV', 4, vc=6)]),
    'store_d0_vs_regular_store': ('store_d0', [lm(vd=0), TT.TTSFPSTORE(6, 3, 0, 0)]),
    'none_regular_mov': ('none', [lm(vd=0), W('MOV', 4, vc=6)]),
  }
  CONFIGS['store_d0'] = {STORE: byte(3, delay=0)}
  for name, (config, body) in cases.items():
    save(dict(kind='loadmacro_collision', case=name, **run(bh, config, body)))
