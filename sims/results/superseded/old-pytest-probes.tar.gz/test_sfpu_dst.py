"""FPU -> SFPLOAD visibility: ELWMUL accumulates into Dst rows, then after g instructions (TTNOP or SFPNOP) an SFPLOAD
reads the same rows. Value shows whether the load saw the FPU result; timing (loop slope) shows any stall.
Setup borrowed from blackhole-py-old tests/timing/test_fpu_sfpu_interleave.py (A=B=1/64, FP32 Dst, ELWMUL adds
1/4096 per instruction to an 8x16 block).
"""
import json, os
from pathlib import Path
from statistics import median
from struct import unpack

import pytest
from asm import Asm
from ttko.isa import R, Tensix as TT
from tests.profiler import Profiler
from tests.movement.unpacker import unpack as u
from tests.movement.packer.pack import _configure_row_addressing, _configure_row_mop, _set_dst_position
from tests.operation_pocs.sfpu_math.emit import constant
from tests.timing.test_fpu_sfpu_interleave import A, B, READY, OUTPUT, initial
from test_sfpu_matrix import save, prefetch_on  # noqa: F401


def images(gap, gap_kind, loop=None, batch=1, sf_row=None, sfpu='load'):
  loader, math, packer = (Asm(role) for role in ('trisc0', 'trisc1', 'trisc2'))
  u.configure_unpack_pair(loader, A, B)
  loader.emit(TT.TTSETADCXX(3, 1023, 0))
  u.configure_mop(loader, u._mop_loop_words(1, 1, start=u._unpacr(0), loop=u._unpacr(1), last=u._unpacr(1),
                                            outer_last=u._unpacr(1)))
  u.run_mop(loader)
  u.stall(loader, u.Stall.SYNC, u.Wait.UNPACK0 | u.Wait.UNPACK1)
  u.sem_get(loader, u.Sem.UNPACK_SYNC)
  u.pc_sync(loader)
  loader.write(READY, 1)
  loader.fence()
  math.wait(READY, 1, bytes=4)
  u.configure_fp32_dst(math, 0)
  for register in (11, 12, 28, 47): u._set_thread_cfg(math, register, 0)
  math.emit(TT.TTSETRWC(0, 0, 0, 0, 0, 15))
  math.emit(TT.TTZEROACC(3, 1, 0, 1, 0))
  u.stall(math, u.Stall.MATH, u.Wait.SRCA_VLD | u.Wait.SRCB_VLD)
  for tile in (0, 2):
    for row in range(tile * 64, tile * 64 + 64, 8): math.emit(TT.TTMOVA2D(0, 0, 0, 2, row))
  u.stall(math, u.Stall.SFPU, u.Wait.MATH)
  math.emit(TT.TTSFPENCC(0, 0, 0, 2))
  for reg in range(8): constant(math, reg, 0.)
  u.stall(math, u.Stall.SYNC, u.Wait.MATH | u.Wait.SFPU)
  u.pc_sync(math)
  gapw = TT.TTNOP() if gap_kind == 'ttnop' else TT.TTSFPNOP()
  p = None
  if loop is None:
    math.emit(TT.TTELWMUL(0, 0, 0, 0, 0))
    for _ in range(gap): math.emit(gapw)
    math.emit(TT.TTSFPLOAD(0, 3, 0, 0))
  else:
    counter = math.reg(); math.li(counter, loop)
    p = Profiler(math)
    p.record('loop')
    math.label('l')
    for start in range(0, 16, batch):
      for i in range(start, start + batch): math.emit(TT.TTELWMUL(0, 0, 0, 0, (i % 8) * 8))
      for _ in range(gap): math.emit(gapw)
      for i in range(start, start + batch):
        row = (i % 8) * 8 if sf_row is None else sf_row + 2 * (i % 16)
        if sfpu == 'load': math.emit(TT.TTSFPLOAD(i % 4, 3, 0, row))
        elif sfpu == 'store': math.emit(TT.TTSFPSTORE(i % 4, 3, 0, row))
        else: math.emit(TT.TTSFPMAD(10, 10, i % 4, i % 4, 0))
    math.addi(counter, counter, -1)
    math.bne(counter, R.ZERO, 'l')
    u.stall(math, u.Stall.SYNC, u.Wait.MATH | u.Wait.SFPU)
    u.pc_sync(math)
    p.record('loop')
  u.stall(math, u.Stall.SYNC, u.Wait.MATH | u.Wait.SFPU)
  for pos in range(4): math.emit(TT.TTSFPSTORE(0, 3, 0, 128 + 2 * pos))
  u.stall(math, u.Stall.SYNC, u.Wait.SFPU)
  u.pc_sync(math)
  math.emit(TT.TTSETRWC(3, 0, 0, 0, 0, 15))
  u.publish_dst(math)
  u.sem_wait(packer, u.Sem.MATH_PACK, u.SemWait.ON_ZERO, u.Stall.TDMA)
  u.configure_packer(packer, u.F32)
  _configure_row_addressing(packer)
  _configure_row_mop(packer, 64, close=True)
  u.pc_sync(packer)
  _set_dst_position(packer, 2, 0)
  packer.write(u.PackCfg.L1_DESTINATION, ((OUTPUT + 2 * 4096) >> 4) - 1 | 0x80000000)
  packer.write(u.PackCfg.DESTINATION_OFFSET, 0)
  packer.emit(TT.TTSETADCXX(4, 15, 0))
  u.run_mop(packer)
  u.stall(packer, u.Stall.SYNC, u.Wait.PACK0)
  u.pc_sync(packer)
  u.sem_get(packer, u.Sem.MATH_PACK)
  return {k.role: k.lower() for k in (loader, math, packer)}, p


@pytest.mark.parametrize('gap_kind', ('ttnop', 'sfpnop'))
def test_fpu_to_sfpload(bh, gap_kind):
  for gap in range(0, 7):
    imgs, _ = images(gap, gap_kind)
    seen = []
    for _ in range(3):
      bh.launch(imgs, l1=initial())
      vals = unpack('<128f', bh.read_l1(bh.core, OUTPUT + 2 * 4096, 512))
      seen.append(sorted(set(vals)))
    timing = []
    for n in (16, 48):
      imgs, p = images(gap, gap_kind, loop=n)
      s = []
      for i in range(4):
        bh.launch(imgs, l1=initial(), profiler=p)
        if i: s.append(p.last['loop'])
      timing.append(median(s))
    save(dict(kind='fpu_to_sfpload', gap=gap, gap_kind=gap_kind, values=[[float(x) for x in s] for s in seen],
              expected_new=1 / 64 + 1 / 4096, expected_old=1 / 64,
              slope_per_pair=(timing[1] - timing[0]) / (32 * 16), pair_insns=2 + gap))


def test_dst_half_sweep(bh):
  """Steady cycles per (ELWMUL + SFPU op) by batch size and SFPU row: same block, same half other tile, other half."""
  for sfpu in ('load', 'store', 'mad'):
    for where, row in (('same_rows', None), ('same_half', 128), ('other_half', 256 + 128)):
      if sfpu == 'mad' and where != 'same_rows': continue
      for batch in (1, 2, 4, 8, 16):
        timing = []
        for n in (16, 48):
          imgs, p = images(0, 'ttnop', loop=n, batch=batch, sf_row=row, sfpu=sfpu)
          s = []
          for i in range(4):
            bh.launch(imgs, l1=initial(), profiler=p)
            if i: s.append(p.last['loop'])
          timing.append(median(s))
        save(dict(kind='dst_half', sfpu=sfpu, where=where, batch=batch, slope_per_pair=(timing[1] - timing[0]) / (32 * 16)))
